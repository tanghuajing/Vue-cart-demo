var vm = new Vue({
    el: ".address",
    data: {
        limitNumber: 3,
        addressList: [],
        currentIndex: 0,
        shoppingMethod: 1,
        delFlag: false,
        currentAddress: [],
        editFlag: false
    },
    mounted: function () {
        this.$nextTick(function () {
            this.getAddressList();
        });
    },
    computed: {
        filterAddress: function () {
            return this.addressList.slice(0, this.limitNumber);
        }
    },
    methods: {
        getAddressList: function () {
            var _this = this;
            this.$http.get('data/address.json').then(function (response) {
                var res = response.data;
                if (res.status == "0") {
                    _this.addressList = res.result;
                }

            })
        },
        ShowOrHide: function () {
            if (this.limitNumber == 3) {
                this.limitNumber = this.addressList.length;
            } else {
                this.limitNumber = 3;
            }
        },
        setDefault: function (addressId) {
            this.addressList.forEach(function (address, index) {
                if (address.addressId == addressId) {
                    address.isDefault = true;
                } else {
                    address.isDefault = false;
                }
            })
        },
        delConfirm: function (item) {
            this.delFlag = true;
            this.currentAddress = item;
        },
        delAddress: function () {
            var index = this.addressList.indexOf(this.currentAddress);
            this.addressList.splice(index, 1);
            this.delFlag = false;
        },
        addAddress: function () {
            this.editFlag = true;
            this.currentAddress = [];
        },
        editConfirm: function (item) {
            this.editFlag = true;
            this.currentAddress = item;
        },
        SaveAddress: function () {
            var _this = this;
            if (_this.currentAddress.length > 0) {//修改
                this.addressList.forEach(function (address, index) {
                    if (address.addressId == _this.currentAddress.addressId) {
                        address = _this.currentAddress;
                    }
                });
            } else {//增加
                this.addressList.push(_this.currentAddress);
            }
            this.limitNumber = this.addressList.length;
            this.editFlag = false;
        }
    }
});